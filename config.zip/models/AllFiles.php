<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "all_files".
 *
 * @property int $id
 * @property int|null $id_padre
 * @property resource|null $f_content
 * @property string|null $entita
 * @property string|null $nomefile
 * @property string|null $estensione
 * @property string|null $origine
 * @property string|null $nota
 */
class AllFiles extends \yii\db\ActiveRecord
{
    /**
     * File temporaneo per l'upload
     */
    public $uploadFile;

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'all_files';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_padre'], 'integer'],
            [['f_content'], 'string'],
            [['entita'], 'string', 'max' => 128],
            [['nomefile'], 'string', 'max' => 260],
            [['estensione'], 'string', 'max' => 10], // Aumentato da 3 a 10 per estensioni come 'docx'
            [['origine'], 'string', 'max' => 1],
            [['nota'], 'string'],
            // Regola per il file upload
            [['uploadFile'], 'file', 'skipOnEmpty' => true, 'extensions' => 'pdf, doc, docx, xls, xlsx, jpg, jpeg, png, gif, zip, rar, txt'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'id_padre' => 'ID Padre',
            'f_content' => 'Contenuto File',
            'entita' => 'Entità',
            'nomefile' => 'Nome File',
            'estensione' => 'Estensione',
            'origine' => 'Origine',
            'nota' => 'Nota',
            'uploadFile' => 'File da caricare'
        ];
    }

    /**
     * Metodo per caricare il file
     */
    public function upload()
    {
        if ($this->validate()) {
            // Salvataggio fisico del file (opzionale)
            $uploadPath = Yii::getAlias('@webroot/uploads/');
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }

            $fileName = $this->id . '_' . str_replace(' ', '_', $this->uploadFile->baseName) . '.' . $this->uploadFile->extension;

            if ($this->uploadFile->saveAs($uploadPath . $fileName)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Metodo per ottenere la dimensione del file in formato leggibile
     */
    public function getFileSize()
    {
        if ($this->f_content) {
            $bytes = strlen($this->f_content);
            $units = ['B', 'KB', 'MB', 'GB'];

            for ($i = 0; $bytes > 1024; $i++) {
                $bytes /= 1024;
            }

            return round($bytes, 2) . ' ' . $units[$i];
        }
        return 'N/A';
    }

    /**
     * Metodo per ottenere l'icona del file basata sull'estensione
     */
    public function getFileIcon()
    {
        $iconMap = [
            'pdf' => 'file-pdf',
            'doc' => 'file-word',
            'docx' => 'file-word',
            'xls' => 'file-excel',
            'xlsx' => 'file-excel',
            'jpg' => 'file-image',
            'jpeg' => 'file-image',
            'png' => 'file-image',
            'gif' => 'file-image',
            'zip' => 'file-archive',
            'rar' => 'file-archive',
            'txt' => 'file-alt',
        ];

        return $iconMap[strtolower($this->estensione)] ?? 'file';
    }

    /**
     * Metodo per verificare se il file è un'immagine
     */
    public function isImage()
    {
        $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
        return in_array(strtolower($this->estensione), $imageExtensions);
    }

    /**
     * Metodo per ottenere il path fisico del file
     */
    public function getFilePath()
    {
        $uploadPath = Yii::getAlias('@webroot/uploads/');
        $fileName = $this->id . '_' . str_replace(' ', '_', $this->nomefile);
        return $uploadPath . $fileName;
    }

    /**
     * Metodo per verificare se il file fisico esiste
     */
    public function fileExists()
    {
        return file_exists($this->getFilePath());
    }

    /**
     * Override del metodo delete per eliminare anche il file fisico
     */
    public function delete()
    {
        $filePath = $this->getFilePath();

        // Elimina prima il record dal database
        $result = parent::delete();

        // Se l'eliminazione dal database è riuscita, elimina anche il file fisico
        if ($result && file_exists($filePath)) {
            unlink($filePath);
        }

        return $result;
    }

    /**
     * Relazione con il modello padre (XtravelHead)
     */
    public function getXtravelHead()
    {
        return $this->hasOne(XtravelHead::class, ['th_id' => 'id_padre']);
    }
}
