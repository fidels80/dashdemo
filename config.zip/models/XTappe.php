<?php

namespace app\models;

use Yii;
use app\models\Xvenue;
/**
 * This is the model class for table "x_tappe".
 *
 * @property string $id_tappa
 * @property int $th_id
 * @property string $data
 * @property string $citta
 * @property bool|null $evaso
 */
class Xtappe extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'x_tappe';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db5');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_tappa'], 'string'],
            [['th_id', 'data', 'citta'], 'required'],
            [['th_id'], 'integer'],
            [['data'], 'safe'],
            [['evaso'], 'boolean'],
            [['citta'], 'string', 'max' => 250],
            [['id_tappa'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_tappa' => 'Id Tappa',
            'th_id' => 'Th ID',
            'data' => 'Data',
            'citta' => 'Citta',
            'evaso' => 'Evaso',
        ];
    }
    public function getDecodevenue()
    {
        // Usa la relazione per accedere alle righe e somma i prezzi
    
    $decode=Xvenue::find()->select(['venue'])->where(['id'=>$this->citta])
    ->one();
    
        return $decode['venue'];
    
    }
}
