<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "Docommessa".
 *
 * @property int $Id_DOCommessa
 * @property string $Cd_DOCommessa
 * @property string $Descrizione Descrizione commessa.
 * @property string|null $DescrizioneBreve
 * @property string|null $Cd_CF
 * @property string|null $Cd_DOCommessaStato
 * @property string|null $DataInizio
 * @property string|null $DataFinePresunta
 * @property string|null $DataFineReale
 * @property string|null $NoteDoCommessa
 * @property string $UserIns
 * @property string $UserUpd
 * @property string $TimeIns
 * @property string $TimeUpd
 * @property string|null $Ts
 * @property string|null $NoteXML
 * @property string|null $Attributi
 * @property string $Sconto Espressione per la % di sconto
 * @property string $Provvigione Espressione per la % di provvi
 */
class Docommessa extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'Docommessa';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db5');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Cd_DOCommessa'], 'required'],
            [['DataInizio', 'DataFinePresunta', 'DataFineReale', 'TimeIns', 'TimeUpd', 'Ts'], 'safe'],
            [['NoteDoCommessa', 'NoteXML', 'Attributi'], 'string'],
            [['Cd_DOCommessa', 'Sconto', 'Provvigione'], 'string', 'max' => 10],
            [['Descrizione'], 'string', 'max' => 50],
            [['DescrizioneBreve'], 'string', 'max' => 20],
            [['Cd_CF'], 'string', 'max' => 7],
            [['Cd_DOCommessaStato'], 'string', 'max' => 3],
            [['UserIns', 'UserUpd'], 'string', 'max' => 48],
            [['Cd_DOCommessa'], 'unique'],
            [['Cd_CF'],'string', 'max' => 3 ],
            [['Cd_DOCommessaStato'],'string', 'max' => 3],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id_DOCommessa' => 'Id Do Commessa',
            'Cd_DOCommessa' => 'Cd Do Commessa',
            'Descrizione' => 'Descrizione',
            'DescrizioneBreve' => 'Descrizione Breve',
            'Cd_CF' => 'Cd Cf',
            'Cd_DOCommessaStato' => 'Cd Do Commessa Stato',
            'DataInizio' => 'Data Inizio',
            'DataFinePresunta' => 'Data Fine Presunta',
            'DataFineReale' => 'Data Fine Reale',
            'NoteDoCommessa' => 'Note Do Commessa',
            'UserIns' => 'User Ins',
            'UserUpd' => 'User Upd',
            'TimeIns' => 'Time Ins',
            'TimeUpd' => 'Time Upd',
            'Ts' => 'Ts',
            'NoteXML' => 'Note Xml',
            'Attributi' => 'Attributi',
            'Sconto' => 'Sconto',
            'Provvigione' => 'Provvigione',
        ];
    }
}
