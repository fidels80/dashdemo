<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "DOSottoCommessa".
 *
 * @property int $Id_DOSottoCommessa
 * @property string $Cd_DOCommessa
 * @property string $Cd_DOSottoCommessa
 * @property string $Descrizione Descrizione commessa.
 * @property string|null $DescrizioneBreve
 * @property string|null $Cd_CF
 * @property string|null $Cd_DOCommessaStato
 * @property string|null $DataInizio
 * @property string|null $DataFinePresunta
 * @property string|null $DataFineReale
 * @property string|null $NoteDoSottoCommessa
 * @property string $UserIns
 * @property string $UserUpd
 * @property string $TimeIns
 * @property string $TimeUpd
 * @property string|null $Ts
 * @property string|null $NoteXML
 * @property string|null $Attributi
 * @property string $Sconto Espressione per la % di sconto
 * @property string $Provvigione Espressione per la % di provvi
 */
class Sottocommessa extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'DOSottoCommessa';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db5');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Cd_DOCommessa', 'Cd_DOSottoCommessa'], 'required'],
            [['DataInizio', 'DataFinePresunta', 'DataFineReale'], 
             'safe'],
            [['NoteDoSottoCommessa', 'NoteXML', 'Attributi'], 'string'],
            [['Cd_DOCommessa', 'Sconto', 'Provvigione'], 'string', 'max' => 10],
            [['Cd_DOSottoCommessa', 'DescrizioneBreve'], 'string', 'max' => 20],
            [['Descrizione'], 'string', 'max' => 50],
            [['Cd_CF'], 'string', 'max' => 7],
            [['Cd_DOCommessaStato'], 'string', 'max' => 3],
            [['UserIns', 'UserUpd'], 'string', 'max' => 48],
            [['Cd_DOSottoCommessa'], 'unique'],
            [['Cd_DOCommessa'], 'exist', ],
            [['Cd_CF'], 'exist', 'skipOnError' => true, 
            ],
            [['Cd_DOCommessaStato'], 'exist', 'skipOnError' => true, 
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'Id_DOSottoCommessa' => 'Id Do Sotto Commessa',
            'Cd_DOCommessa' => 'Cd Do Commessa',
            'Cd_DOSottoCommessa' => 'Cd Do Sotto Commessa',
            'Descrizione' => 'Descrizione',
            'DescrizioneBreve' => 'Descrizione Breve',
            'Cd_CF' => 'Cd Cf',
            'Cd_DOCommessaStato' => 'Cd Do Commessa Stato',
            'DataInizio' => 'Data Inizio',
            'DataFinePresunta' => 'Data Fine Presunta',
            'DataFineReale' => 'Data Fine Reale',
            'NoteDoSottoCommessa' => 'Note Do Sotto Commessa',
            'UserIns' => 'User Ins',
            'UserUpd' => 'User Upd',
            'TimeIns' => 'Time Ins',
            'TimeUpd' => 'Time Upd',
            'Ts' => 'Ts',
            'NoteXML' => 'Note Xml',
            'Attributi' => 'Attributi',
            'Sconto' => 'Sconto',
            'Provvigione' => 'Provvigione',
        ];
    }
}
