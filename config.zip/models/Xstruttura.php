<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "x_struttura".
 *
 * @property int $id
 * @property string $Struttura
 * @property string|null $Descrizione
 * @property string $Citta
 * @property string|null $Cd_cf
 * @property string|null $Partitaiva
 * @property string|null $xcheck
 */
class Xstruttura extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'x_struttura';
    }

    /**
     * @return \yii\db\Connection the database connection used by this AR class.
     */
    public static function getDb()
    {
        return Yii::$app->get('db5');
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['Struttura', 'Citta'], 'required'],
            [['Struttura'], 'string', 'max' => 80],
            [['Descrizione', 'Citta'], 'string', 'max' => 200],
            [['Cd_cf'], 'string', 'max' => 7],
            [['Partitaiva'], 'string', 'max' => 13],
            // [['xcheck'], 'string', 'max' => 287],

            [
                ['Struttura', 'Descrizione', 'Citta', 'Cd_cf', 'Partitaiva'],
                'unique',
                'targetAttribute' => ['Struttura', 'Descrizione', 'Citta', 'Cd_cf', 'Partitaiva'],
                'message' => 'Esiste già una struttura con questi dati (combinazione duplicata).'
            ],
        
           ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'Struttura' => 'Struttura',
            'Descrizione' => 'Descrizione',
            'Citta' => 'Citta',
            'Cd_cf' => 'Cd Cf',
            'Partitaiva' => 'Partitaiva',
            'xcheck' => 'Xcheck',
        ];
    }
}
