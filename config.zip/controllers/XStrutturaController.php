<?php

namespace app\controllers;

use Yii;
use app\models\Xstruttura;
use app\models\XstrutturaSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * XstrutturaController implements the CRUD actions for Xstruttura model.
 */
class XstrutturaController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Xstruttura models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new XstrutturaSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Xstruttura model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Xstruttura model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Xstruttura();

        if ($model->load(Yii::$app->request->post())) {
            if ($model->save()) {
                // Se è una richiesta AJAX, ritorna JSON
                if (Yii::$app->request->isAjax) {
                    return $this->asJson([
                        'success' => true,
                        'message' => 'Struttura creata con successo'
                    ]);
                }
                return $this->redirect(['view', 'id' => $model->id]);
            }
        }

        // Se è una richiesta AJAX, ritorna solo la form senza layout
        if (Yii::$app->request->isAjax) {
            return $this->renderAjax('createaj', [
                'model' => $model,
            ]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Xstruttura model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Xstruttura model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Xstruttura model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Xstruttura the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Xstruttura::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
    public function actionXcaricacitta($q = null)
    {
        $db = Yii::$app->db5;
        $query = new \yii\db\Query;
        $query->select(['cd_citta as id', 'descrizione as text'])
            ->from('x_citta')
            ->where(['like', 'descrizione', $q]);
        // ->limit(20);

        $command = $query->createCommand($db);
        $data = $command->queryAll();
        //var_dump($data); // Aggiungi questa linea per verificare
        //die();


        return \yii\helpers\Json::encode(['items' => $data]);
    }
}
