<footer class="main-footer">
    <strong>Copyright &copy;2025 <a href="https://programma2000.com">Programma 2000 S.r.l.</a>.</strong>
    Tutti i diritti riservati.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 2.5.7
    </div>
</footer>