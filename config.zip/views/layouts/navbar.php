<?php

use yii\helpers\Html;

\hail812\adminlte3\assets\FontAwesomeAsset::register($this);
\hail812\adminlte3\assets\AdminLteAsset::register($this);
$this->registerCssFile('https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback');

$assetDir = Yii::$app->assetManager->getPublishedUrl('@vendor/almasaeed2010/adminlte/dist');

$publishedRes = Yii::$app->assetManager->publish('@vendor/hail812/yii2-adminlte3/src/web/js');
$this->registerJsFile($publishedRes[1] . '/control_sidebar.js', ['depends' => '\hail812\adminlte3\assets\AdminLteAsset']);


$usrid = Yii::$app->user->Id;
if ($usrid !== null) {
    $ris = (new \yii\db\Query())
        ->select(['lastlogin'])
        ->from('user')
        ->where(['id' => $usrid])
        ->one();
}
?>
<script>
    function dm() {
        console.log($(this));
        if ($('body').hasClass('dark-mode')) {
            $('body').removeClass('dark-mode');
        } else {
            $('body').addClass('dark-mode');
        }
    };
</script>

<nav class="main-header navbar navbar-expand navbar-white navbar-light">

    <ul class="navbar-nav">



        <li class="nav-item d-none d-sm-inline-block"> <?php
                                                        // 1. DEFAULT: Immagine di fallback
                                                        $imageSrc = \Yii::getAlias('@web') . '/uploads/_____logotour.png';

                                                        try {
                                                            // 2. LOGICA DB
                                                            $usrid = \Yii::$app->user->Id;

                                                            if ($usrid) {
                                                                // A. Recuperiamo il cd_cli dalla tabella user
                                                                $userRow = (new \yii\db\Query())
                                                                    ->select(['cd_cli'])
                                                                    ->from('{{%user}}')
                                                                    ->where(['id' => $usrid])
                                                                    ->one();

                                                                $rawCdCli = $userRow['cd_cli'] ?? null;
                                                                $cdCli = null;

                                                                // *** NUOVA LOGICA DI ESTRAZIONE ***
                                                                if ($rawCdCli) {
                                                                    // 1. Tentiamo di convertire la stringa serializzata in array
                                                                    $data = @unserialize($rawCdCli);

                                                                    if ($data !== false && is_array($data)) {
                                                                        // Se è un array, prendiamo il PRIMO elemento
                                                                        $firstItem = reset($data);
                                                                        $cdCli = trim($firstItem);
                                                                    } else {
                                                                        // Caso di sicurezza: usiamo il valore così com'è
                                                                        $cdCli = trim($rawCdCli);
                                                                    }
                                                                }

                                                                if ($cdCli) {
                                                                    // B. Recuperiamo l'immagine
                                                                    $doc = (new \yii\db\Query())
                                                                        ->select(['Content', 'FileExt'])
                                                                        ->from('adb_auxcoop.dbo.DmsDocument')
                                                                        ->where([
                                                                            'EntityTable' => 'CF',
                                                                            'EntityId' => $cdCli
                                                                        ])
                                                                        ->limit(1)
                                                                        ->one();

                                                                    // C. Controllo contenuto e generazione immagine
                                                                    if ($doc && !empty($doc['Content'])) {

                                                                        $ext = strtolower(trim($doc['FileExt'], '. '));

                                                                        switch ($ext) {
                                                                            case 'png':
                                                                                $mimeType = 'image/png';
                                                                                break;
                                                                            case 'jpg':
                                                                            case 'jpeg':
                                                                                $mimeType = 'image/jpeg';
                                                                                break;
                                                                            case 'bmp':
                                                                                $mimeType = 'image/bmp';
                                                                                break;
                                                                            case 'gif':
                                                                                $mimeType = 'image/gif';
                                                                                break;
                                                                            default:
                                                                                $mimeType = 'image/jpeg';
                                                                                break;
                                                                        }

                                                                        $content = $doc['Content'];

                                                                        if (is_resource($content)) {
                                                                            $content = stream_get_contents($content);
                                                                        }

                                                                        if ($content) {
                                                                            $base64 = base64_encode($content);
                                                                            $imageSrc = "data:{$mimeType};base64,{$base64}";
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        } catch (\Exception $e) {
                                                            // In caso di errore, rimane l'immagine di default
                                                            yii::error('errore logo nav: ' . $e->getMessage());
                                                        }
                                                        ?>

            <img src="<?php echo $imageSrc; ?>"
                alt="Planorys"
                class="img-circle elevation-3"
                width="50"
                height="50"
                style="opacity: .8; margin-left: 10px;">
        </li>
    </ul>

    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button" data-enable-remember="true">
                <i class="fas fa-bars"></i>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                <i class="fas fa-expand-arrows-alt"></i>
            </a>
        </li>

        <li class="nav-item">
            <?= Html::a(
                '<i class="fas fa-sign-out-alt"></i>',
                ['/site/logout'],
                ['data-method' => 'post', 'class' => 'nav-link']
            ) ?>
        </li>

    </ul>
</nav>