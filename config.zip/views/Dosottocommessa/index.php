<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Gestione Sottocommesse';

// Registrazione Asset come nel tuo esempio
$this->registerCssFile('https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css');
$this->registerCssFile('https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap4.min.css');

$this->registerJsFile('https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);
$this->registerJsFile('https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);
$this->registerJsFile('https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);
$this->registerJsFile('https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap4.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);
$this->registerJsFile('https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);
$this->registerJsFile('https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);
$this->registerJsFile('https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);
?>

<style>
    .nowrap {
        white-space: nowrap;
    }

    .table-sottocommesse th {
        background-color: #f8f9fa;
        font-size: 13px;
    }

    .table-sottocommesse td {
        font-size: 12px;
        vertical-align: middle;
    }

    .badge-stato {
        font-size: 10px;
        padding: 5px;
    }

    .nowrap {
        white-space: nowrap;
    }



    /* Evidenzia i campi obbligatori */
    .required-label:after {
        content: " *";
        color: red;
    }



    /* Forza l'allineamento delle colonne DataTables */
    .dataTables_scrollFootInner,
    .dataTables_scrollFootInner table {
        width: 100% !important;
    }

    .content {
        width: 95%;
    }
</style>
<div class="dosottocommessa-index">
    <br>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4><i class="fas fa-list"></i> Riepilogo Sottocommesse</h4>
        <?= Html::a('<i class="fa fa-plus"></i> Crea Nuova', ['create'], ['class' => 'btn btn-success btn-sm']) ?>
    </div>

    <table id="tabella-sottocommesse" class="table table-sm table-bordered table-hover display w-100">
        <thead>
            <tr>
                <th class="table-totheadhotel">ID</th>
                <th class="table-totheadhotel">Commessa Padre</th>
                <th class="table-totheadhotel">Cod. Sotto</th>
                <th class="table-totheadhotel">Descrizione</th>
                <th class="table-totheadhotel">Cliente (Anagrafica)</th>
                <th class="table-totheadhotel">Stato</th>
                <th class="table-totheadhotel text-center">Data Inizio</th>
                <th class="table-totheadhotel text-center">Data Fine</th>
                <th class="table-totheadhotel text-center">Azioni</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $models = $dataProvider->getModels();
            foreach ($models as $model):
                // DECODIFICA CLIENTE
                // Se hai definito la relazione 'anagrafica' nel model:
                $cliente = isset($model->anagrafica) ? $model->anagrafica->Descrizione : $model->Cd_CF;
            ?>
                <tr>
                    <td><?= $model->Id_DOSottoCommessa ?></td>
                    <td><strong><?= Html::encode($model->Cd_DOCommessa) ?></strong></td>
                    <td><?= Html::encode($model->Cd_DOSottoCommessa) ?></td>
                    <td><small><?= Html::encode($model->Descrizione) ?></small></td>
                    <td><?= Html::encode($model->getDescrizioneCliente()) ?></td>
                    <td class="text-center">
                        <span class="badge badge-info badge-stato">
                            <?= Html::encode($model->getDescrizioneStato()) ?>
                        </span>
                    </td>
                    <td class="text-center nowrap"><?= $model->DataInizio ? date('d/m/Y', strtotime($model->DataInizio)) : '-' ?></td>
                    <td class="text-center nowrap"><?= $model->DataFinePresunta ? date('d/m/Y', strtotime($model->DataFinePresunta)) : '-' ?></td>
                    <td class="text-center nowrap">
                        <?= Html::a('<i class="fas fa-eye"></i>', ['view', 'id' => $model->Cd_DOSottoCommessa], ['class' => 'btn btn-xs btn-outline-secondary']) ?>
                        <?= Html::a('<i class="fas fa-edit"></i>', ['update', 'id' => $model->Cd_DOSottoCommessa], ['class' => 'btn btn-xs btn-outline-primary']) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>

    </table>
</div>

<?php
$this->registerJsFile('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js', ['depends' => [\yii\web\JqueryAsset::class]]);
$this->registerJsFile('https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js', ['depends' => [\yii\web\JqueryAsset::class]]);
$this->registerJs("
    var table = $('#tabella-sottocommesse').DataTable({
        'language': { 'url': '//cdn.datatables.net/plug-ins/1.13.6/i18n/it-IT.json' },
        'paging': true,
        'pageLength': 25,
        'searching': true,
        'info': true,
        'dom': 'Bfrtip',
 'buttons': [
            { 
                extend: 'copy', 
                className: 'btn btn-secondary btn-sm', 
                text: '<i class=\"fas fa-copy\"></i> Copia'
            },
            { 
                extend: 'excel', 
                className: 'btn btn-success btn-sm', 
                text: '<i class=\"fas fa-file-excel\"></i> Excel' 
            },
            { 
                extend: 'pdf', 
                className: 'btn btn-danger btn-sm', 
                text: '<i class=\"fas fa-file-pdf\"></i> PDF',
                orientation: 'landscape', // Opzionale: orizzontale per far stare più colonne
                pageSize: 'A4'
            },
            { 
                extend: 'print', 
                className: 'btn btn-info btn-sm', 
                text: '<i class=\"fas fa-print\"></i> Stampa' 
            }
        ],
   'columnDefs': [
            { 'width': '5%', 'targets': 0 },  // ID molto stretto
            { 'width': '7%', 'targets': 1 },  // ID molto stretto
             
            { 'width': '10%', 'targets': 5 },  // Stato stretto
              { 'width': '5%', 'targets': 4 },  // Stato stretto
            { 'width': '30%', 'targets': 3 }, // Descrizione larga
            { 'className': 'nowrap', 'targets': [0,  5, 6, 7, 8] } // Evita a capo su tutto tranne descrizione
        ],
        'autoWidth': false, // Importante impostarlo a false per far rispettare le larghezze fisse
 
    });

    // Forza l'allineamento
    setTimeout(function() {
        table.columns.adjust().draw();
    }, 500);
");
?>