*-------------------------------------------------------------
* MAIN.PRG  
*-------------------------------------------------------------
* Project: FoxScheduler
* Version: 0.15c
* Release: 2021.06.01
* Author : Guillermo Carrero (Barcelona, Spain) & VFPEncoding
* Email  : vfpencoding@gmail.com
*-------------------------------------------------------------

SET PROCEDURE TO procedimientos ADDITIVE

PUBLIC cMainFile, cNameProp, FileData

LOCAL lcPath
lcPath = ADDBS(JUSTPATH(SYS(16,1)))

SET DEFAULT TO (lcPath)
SET CLASSLIB TO vcx\foxscheduler, vcx\GradObjects, vcx\ctl32 ADDITIVE

FileData = 'Data\data_conf.dll'

Ag_Default = ReadFileData(FileData, 'DATA','DEFAULT')
IF !EMPTY(Ag_Default)
	LcBd = ReadFileData(FileData, m.Ag_default,'BaseD')
	lcProp = ReadFileData(FileData, m.Ag_default,'prop')
	cMainFile = 'Data\' + ALLTRIM(m.LcBd )
	cNameProp = ALLTRIM(m.lcProp)
ELSE
	AgDefault = WriteFileData(FileData, 'DATA','DEFAULT','0')
	cMainFile = 'sampledb'
	cNameProp = 'Agenda de ejemplo'
ENDIF

DO FORM ("Forms\FoxScheduler_Demo")
READ EVENTS

*-------------------------------------------------------------
