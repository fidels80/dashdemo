NOTE acceso al archivo de agendas data_conf.dll

*----------------------------------------------------
FUNCTION WriteFileData(lcFileName as String,lcSection as String ,lcEntry as String ,lcValue as String)
*----------------------------------------------------
* RETORNO: Logico
*----------------------------------------------------
DECLARE INTEGER WritePrivateProfileString ;
	IN WIN32API ;
	STRING cSection,STRING cEntry,STRING cEntry,;
	STRING cFileName


RETURN IIF(WritePrivateProfileString(m.lcSection,m.lcEntry,m.lcValue,m.lcFileName)=1, .T., .F.)
ENDFUNC


*----------------------------------------------------
FUNCTION ReadFileData(lcFileName as String ,lcSection as String ,lcEntry as String)
*----------------------------------------------------
* RETORNO: El valor contenido en la etiqueta solicitada
*----------------------------------------------------
LOCAL lcIniValue, lnResult, lnBufferSize
DECLARE INTEGER GetPrivateProfileString ;
   IN WIN32API ;
   STRING cSection,;
   STRING cEntry,;
   STRING cDefault,;
   STRING @cRetVal,;
   INTEGER nSize,;
   STRING cFileName
lnBufferSize = 255
lcIniValue = spac(lnBufferSize)
lnResult=GetPrivateProfileString(m.lcSection,m.lcEntry,"*NULL*",;
   @lcIniValue,lnBufferSize,m.lcFileName)
lcIniValue=SUBSTR(lcIniValue,1,lnResult)
IF m.lcIniValue="*NULL*"
   m.lcIniValue=.NULL.
ENDIF
RETURN m.lcIniValue
ENDFUNC